# Manual of Style (MoS) for Minutes to Zero

## 1. Punctuation
### 1.1 Em-Dash ( — ) Prohibition
- The em-dash character (U+2014) is **strictly forbidden** in all text content.
- Replace em-dashes with appropriate punctuation based on context:
  - For parenthetical remarks: use commas (e.g., "his account, still active despite his firing, opened...")
  - For sharp breaks or asides where a comma is too weak: use semicolons or periods, or rephrase the sentence for smoother flow.
  - For introducing lists or explanations after a colon: use a colon or rephrase (avoid "colon — em-dash" patterns).
- Goal: Ensure prose flows smoothly like water, without interruptive punctuation.

## 2. Typography
### 2.1 Body Text
- Base font size for body paragraphs shall be consistent and readable (target: 11pt equivalent in reflowable EPUB).
- Line height (leading) shall be set to 1.4× font size for optimal readability.
- Paragraph spacing: uniform spacing (e.g., 0pt before, 6pt after) OR first-line indent only; do not mix indentation and vertical spacing arbitrarily.

### 2.2 Headings and Hierarchy
- Heading levels (h1, h2, h3, etc.) shall follow a clear typographic scale relative to body text.
  - Example scale: h1 = 2.0× body, h2 = 1.5× body, h3 = 1.25× body, h4 = 1.1× body.
- Ensure front matter (title page, copyright, dedication, etc.) uses subdued styling that does not overpower the body text.
  - Front matter may use smaller font sizes, lighter weights, or simple centering, but must remain legible and proportionate.

### 2.3 Consistency
- All text content (including front matter, chapters, back matter) shall adhere to the same typographic rules.
- No abrupt font-size jumps; all sizes shall derive from the defined scale.

## 3. Formatting
### 3.1 File Formats
- Source manuscripts shall be maintained in clean Markdown or XHTML with minimal inline styling.
- EPUB production shall separate content (XHTML) from presentation (CSS).

### 3.2 CSS Guidelines
- Use relative units (em, rem) for font sizes and spacing to ensure scalability.
- Avoid hard-coded pixel values for text properties where possible.
- Define base font size on the `body` element; derive all other sizes from it.

## 4. Prose Flow
- Sentences should vary in length but maintain rhythmic readability.
- Avoid excessive use of any punctuation that creates a "stop-and-go" reading experience.
- Prefer simple, clear constructions over complex interruptions.

---
*This Manual of Style is binding for all revisions of the Minutes to Zero manuscript.*
