# Manual of Style (MoS) for Minutes to Zero - GYLC Strict Style Protocol

## 1. Punctuation
### 1.1 Em-Dash ( — ) Prohibition
- The em-dash character (U+2014) is **strictly forbidden** in all text content.
- Replace em-dashes with appropriate punctuation based on context:
  - For parenthetical remarks: use commas (e.g., "his account, still active despite his firing, opened...")
  - For sharp breaks or asides where a comma is too weak: use semicolons or periods, or rephrase the sentence for smoother flow.
  - For introducing lists or explanations after a colon: use a colon or rephrase (avoid "colon — em-dash" patterns).
- Goal: Ensure prose flows smoothly like water, without interruptive punctuation.

## 2. Prose Flow and Lexical Constraints
### 2.1 Sentence Construction
- Sentences should vary in length but maintain rhythmic readability.
- Avoid excessive use of any punctuation that creates a "stop-and-go" reading experience.
- Prefer simple, clear constructions over complex interruptions.
- Vary sentence endings to avoid rhythmic monotony; avoid ending multiple consecutive sentences with identical grammatical structures (e.g., repeated causal clauses beginning with "because", "since", or "as a result").

### 2.2 Weak Qualifiers and Filler Words (Anti-Slop Index)
The following words and phrases are **strictly prohibited** as they add no factual velocity and constitute lexical padding:
- actually, merely, simply, basically, fundamentally, specifically, however, completely, absolutely, perfectly, entirely, explicitly, actively, essentially, virtually, really, quite, rather, somewhat, somewhat, almost, nearly, practically, effectively, essentially, largely, mainly, mostly, primarily, predominantly, largely, chiefly, principally, mainly, mostly, largely, primarily, predominantly, chiefly, principally
- Academic clichés: utilize, framework, paradigm, nuanced, mitigate, synergy, impactful, leverage, optimize, streamline, harness, facilitate
- Binary foils: Avoid "Not X but Y" structures; state what the concept IS directly.

### 2.3 Causal Density and Connectors
- Establish the relationship between every logical movement using a variety of causal markers: because, since, so, thus, as a result, for this reason, as, due to, owing to, consequently, therefore, hence.
- **Anti-Repetition Mandate**: Avoid over-reliance on any single conjunction. Distribute causal weight across different markers to prevent a robotic, artificial cadence.
- No parenthetical phrases: State all information directly within the primary sentence structure.

### 2.4 Metaphor-Mapping Requirements
- The reader must be able to "see" the mechanics of the argument.
- Replace high-acuity vocabulary with intuitive metaphors without sacrificing the "Truth Upfront" standard.
- Use concrete, tangible comparisons to explain abstract concepts.

## 3. Typography
### 3.1 Body Text
- Base font size for body paragraphs shall be consistent and readable (target: 11pt equivalent in reflowable EPUB).
- Line height (leading) shall be set to 1.4× font size for optimal readability.
- Paragraph spacing: uniform spacing (e.g., 0pt before, 6pt after) OR first-line indent only; do not mix indentation and vertical spacing arbitrarily.

### 3.2 Headings and Hierarchy
- Heading levels (h1, h2, h3, etc.) shall follow a clear typographic scale relative to body text.
  - Example scale: h1 = 2.0× body, h2 = 1.5× body, h3 = 1.25× body, h4 = 1.1× body.
- Ensure front matter (title page, copyright, dedication, etc.) uses subdued styling that does not overpower the body text.
  - Front matter may use smaller font sizes, lighter weights, or simple centering, but must remain legible and proportionate.

### 3.3 Consistency
- All text content (including front matter, chapters, back matter) shall adhere to the same typographic rules.
- No abrupt font-size jumps; all sizes shall derive from the defined scale.

## 4. Formatting
### 4.1 File Formats
- Source manuscripts shall be maintained in clean Markdown or XHTML with minimal inline styling.
- EPUB production shall separate content (XHTML) from presentation (CSS).

### 4.2 CSS Guidelines
- Use relative units (em, rem) for font sizes and spacing to ensure scalability.
- Avoid hard-coded pixel values for text properties where possible.
- Define base font size on the `body` element; derive all other sizes from it.

## 5. Micro-Macro Bridging Mandate (Enforceable Addendum)
### 5.1 The Alternating Lens Requirement
Every chapter must integrate the micro narrative with the macro consequence. The text must link a specific, documented action taken by the Akhter brothers directly to the corresponding vulnerability within the federal contractor state. A chapter must never exist exclusively as biography or exclusively as technical policy.

### 5.2 The PACER Anchoring Rule
To prevent fictionalized drift within the character-driven segments, every psychological or motivational claim must anchor to a verified primary source. The agent must derive the character focus from verifiable actions documented in the source registry rather than relying upon speculative interiority.

### 5.3 The Pre-Draft Logic Block
Before generating any chapter text, the drafting agent must output a mandatory logic block. This block must define the Character Pivot and the Structural Pivot for that specific chapter. This requirement forces the agent to establish the causal relationship between the human action and the systemic failure before writing a single sentence of prose.

### 5.4 Protocol Hardcoding
We must append this dual-track architecture directly to the style manual. By integrating these constraints into the primary rule set, we establish a universal enforcement mechanism that applies automatically to every subsequent prompt in the production pipeline.

---
*This Manual of Style is binding for all revisions of the Minutes to Zero manuscript.*