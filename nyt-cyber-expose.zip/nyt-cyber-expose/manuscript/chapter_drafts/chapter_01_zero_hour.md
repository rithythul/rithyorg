# Chapter One: Zero Hour

Muneeb Akhter clicked End meeting in Microsoft Teams at 4:50 p.m. on February 18, 2025.
The system processed his termination command.
A dismissal notice appeared in the Teams interface.

His work credentials stayed active for six minutes after termination.
Opexus failed to deactivate his account per offboarding service level agreements.
The live account maintained connectivity to federal systems.

At 4:56 p.m. Muneeb used those active credentials.
He accessed a federal government database hosted by Opexus.
He entered the Company-1 environment.

Two minutes later at 4:58 p.m. he typed DROP DATABASE dhsprodb.
The command targeted a Department of Homeland Security production system.
The database vanished instantly.

At 4:59 p.m. Muneeb submitted an artificial intelligence query.
He asked how to clear system logs from SQL servers after deleting databases.
The question revealed intent to conceal destructive actions.

Over the next forty seven minutes the brothers worked together.
They deleted databases supporting case management and Freedom of Information Act processing.
Twelve federal agencies lost critical functionality.

The brothers exfiltrated sensitive data during the rampage.
They copied 1,805 EEOC complaint files to a USB drive.
They saved 450 taxpayer records on the same portable storage device.
Government-held personal data left secure control.

Muneeb retained his physical PIV access card despite termination.
The card remained functional for building entry to federal facilities.
He kept potential physical access points.

At 5:52 p.m. the deletion sequence concluded.
Ninety-six United States government databases ceased to exist.
The deletions exposed structural vulnerability in contractor access controls.

Court records confirm the deletions disrupted ongoing investigations.
Agencies delayed benefits processing while restoring data from available backups.
Backups existed only for some systems.
Recovery proved incomplete and costly.

Opexus required immediate account deactivation upon termination per offboarding SLAs.
Federal contracts mandated the same security protocol.
His account should have been dead within minutes.

Instead credentials stayed live for nearly sixty minutes.
The sixty-minute window provided temporal bandwidth for destruction.
The brothers dismantled a year of digital infrastructure in under an hour.

The failure revealed a systemic architectural deficit.
Contractor states efficiently outsource operations and accountability together.
Departing workers retain dangerous access without automated severance.